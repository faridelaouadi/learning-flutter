 extern const unsigned char RunnerVersionString[];
 extern const double RunnerVersionNumber;

 const unsigned char RunnerVersionString[] __attribute__ ((used)) = "@(#)PROGRAM:Runner  PROJECT:Runner-1" "\n";
 const double RunnerVersionNumber __attribute__ ((used)) = (double)1.;
